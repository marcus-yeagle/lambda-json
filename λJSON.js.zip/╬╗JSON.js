// Define the global environment with basic arithmetic functions, comparators, and the 'not' special form
const globalEnv = {
  '+': (args) => {
    if (
      args.every((a) => typeof a === 'number') ||
      args.every((a) => typeof a === 'string')
    ) {
      return args.reduce((acc, val) => acc + val);
    } else {
      // Calling '+' on some unevaluated expression, general case
      const evaluatedArgs = args.map((arg) => {
        if (typeof arg === 'string' || Array.isArray(arg)) {
          return evaluate(arg, globalEnv);
        } else {
          return arg;
        }
      });
    }
  },
  '-': (args) => {
    if (args.every((a) => typeof a === 'number')) {
      return args.reduce((acc, val) => acc - val);
    } else {
      const evaluatedArgs = args.map((arg) => {
        if (typeof arg === 'string' || Array.isArray(arg)) {
          return evaluate(arg, globalEnv);
        } else {
          return arg;
        }
      });
    }
  },
  '*': (args) => {
    if (args.every((a) => typeof a === 'number')) {
      return args.reduce((acc, val) => acc * val);
    } else {
      const evaluatedArgs = args.map((arg) => {
        if (typeof arg === 'string' || Array.isArray(arg)) {
          return evaluate(arg, env);
        } else {
          return arg;
        }
      });
    }
  },
  '/': (args) => args.reduce((acc, val) => acc / val),
  '>': (args) =>
    args.every((val, index) => index === 0 || args[index - 1] > val), // Greater than comparator
  '<': (args) =>
    args.every((val, index) => index === 0 || args[index - 1] < val), // Less than comparator
  not: (args) => !evaluate(args[0]), // 'not' special form
};

const primMathOps = ['+', '-', '*', '/'];

// λ-JSON Literals:
//
// 2, 3, 5 - Numbers
// 'foo', 'bar', baz - Strings
// [], [2, 3, 'cat'], [[], [1], ['2']], [square 3] - Lists
//
//
// Evaluate an expression in the given environment
function evaluate(exp, env) {
  if (typeof exp === 'number') {
    return exp; // Numbers evaluate to themselves
  } else if (typeof exp === 'string') {
    if (exp.startsWith("'")) {
      return exp.substring(1); // Remove the quote symbol and treat it as a literal string
    }
    if (env[exp] !== undefined) {
      return env[exp]; // Variable lookup in the environment
    } else {
      return exp;
    }
  } else if (Array.isArray(exp)) {
    const [operator, ...args] = exp;
    if (operator === 'define') {
      const [variable, value] = args;
      globalEnv[variable] = evaluate(value, env);
      return globalEnv[variable];
    } else if (operator === 'lambda' || operator === 'λ') {
      const [parameters, body] = args;
      return (...evalArgs) => {
        const localEnv = { ...env, ...globalEnv };
        // copy glb env into local and eval args wrt formal params
        parameters.forEach((param, index) => {
          localEnv[param] = evalArgs[index];
        });
        return evaluate(body, localEnv);
      };
    } else if (operator === 'if') {
      const [condition, trueBranch, falseBranch] = args;
      const conditionResult = evaluate(condition, env);
      return conditionResult
        ? evaluate(trueBranch, env)
        : evaluate(falseBranch, env);
    } else if (operator === 'cond') {
      for (const [condition, expr] of args) {
        if (evaluate(condition, env)) {
          return evaluate(expr, env);
        }
      }
      const [condition, expr] = args[args.length - 1]; // enforce last else
      if (condition === 'else') {
        return evaluate(expr, env);
      }
    } else if (operator === 'let') {
      const [bindings, body] = args;
      const localEnv = { ...env };
      bindings.forEach(([variable, value]) => {
        localEnv[variable] = evaluate(value, localEnv);
      });
      return evaluate(body, localEnv);
    } else if (operator === 'quote') {
      return args[0]; // Return the unevaluated value as a literal
    } else if (operator === 'eq?') {
      const [arg1, arg2] = args;
      const value1 = evaluate(arg1, env);
      const value2 = evaluate(arg2, env);
      return value1 === value2;
    } else {
      const evaluatedOperator = evaluate(operator, env);
      const evaluatedArgs = args.map((arg) => {
        if (typeof arg === 'string' || Array.isArray(arg)) {
          return evaluate(arg, env);
        } else {
          return arg;
        }
      });

      if (typeof evaluatedOperator === 'function') {
        // Apply
        if (primMathOps.includes(evaluatedOperator.name)) {
          // Pass args in as JS Array for pimative reduce [a1, a2]
          // console.log('res of apply -> ', evaluatedOperator(evaluatedArgs));
          return evaluatedOperator(evaluatedArgs);
        } else {
          // Otherwise pass the evaluated args to function normally (a1, a2)
          // console.log('res of apply -> ', evaluatedOperator(...evaluatedArgs));
          return evaluatedOperator(...evaluatedArgs);
        }
      } else {
        return exp; // Return the unevaluated expression as a special form
      }
    }
  }
}

// Example usage:
const defineX = ['define', 'x', 1]; // Defines a variable x with value 10
// evaluate(defineX, globalEnv);

// Lambda Example:
const square = ['λ', ['x'], ['*', 'x', 'x']]; // Lambda function to square a number
const squareOfFive = [square, 5]; // Apply the lambda function to the argument 5
// console.log(evaluate(squareOfFive, globalEnv));

// 'let' Example:
const exp4 = [
  'let',
  [
    ['a', 3],
    ['b', 4],
  ],
  ['+', 'a', 'b'],
]; // Evaluates to 7 (3 + 4)

// 'quote' Example:
const exp5 = ['+', 1, 2, ['quote', 'x']]; // Evaluates to 4 (1 + 2 + 'x')

// Lambda function to calculate the nth Fibonacci number
const fib = [
  'define',
  'fib',
  [
    'λ',
    ['n'],
    [
      'cond',
      [['eq?', 'n', 0], 0],
      [['eq?', 'n', 1], 1],
      [
        'else',
        [
          '+',
          ['fib', ['-', 'n', 1]], // Recursive call: Pass 'fib' symbol unevaluated
          ['fib', ['-', 'n', 2]], // Recursive call: Pass 'fib' symbol unevaluated
        ],
      ],
    ],
  ],
];

evaluate(fib, globalEnv);
const fibOf = [fib, 10];
// console.log('-> ', evaluate(fibOf, globalEnv));

// console.log('-> ', evaluate(['+', 2, 'x', 3], globalEnv));
// console.log('-> ', evaluate(['-', 6, 'x', 1], globalEnv));

// Prompt
const readline = require('readline').createInterface({
  input: process.stdin,
  output: process.stdout,
});

// Reader
readline.setPrompt('λ-JSON -> ');
readline.prompt();
readline
  .on('line', function (λexpresison) {
    if (['quit', 'q', 'exit'].includes(λexpresison)) readline.close();
    console.log();
    // Evaluator
    // Printer
    console.log(`${evaluate(eval(λexpresison), globalEnv)}!`);
    // dependent on JS eval to process the text into a JS Array to then be evaluated by λJSON
    console.log();
    readline.prompt();
    // Loop
  })
  .on('close', function () {
    process.exit(0);
  });
